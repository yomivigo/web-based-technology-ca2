# Grayscale Website Template
<img width="1304" alt="Screenshot 2567-07-06 at 11 38 06" src="https://github.com/codepassion-team/website-template-grayscale/assets/15765838/f5ac6d1b-1a31-437f-bb46-396afa2b2711">
